#!/bin/bash

echo "=== INSTALACIÓN RÁPIDA - PRINT SERVER DASHBOARD ==="
echo ""

# Verificar que estemos en el directorio correcto
if [ ! -f "server.js" ]; then
    echo "❌ Error: No se encontró server.js"
    echo "   Asegúrate de estar en el directorio del proyecto"
    exit 1
fi

echo "📋 Verificando prerequisitos..."

# Verificar Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 no está instalado"
    echo "   Ejecuta: sudo apt install python3 python3-pip python3-venv"
    exit 1
fi

# Verificar Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js no está instalado"
    echo "   Ejecuta: curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash - && sudo apt install -y nodejs"
    exit 1
fi

# Verificar MySQL
if ! command -v mysql &> /dev/null; then
    echo "❌ MySQL no está instalado"
    echo "   Ejecuta: sudo apt install mysql-server"
    exit 1
fi

echo "✅ Prerequisitos verificados"
echo ""

echo "📖 Para instalación completa, consulta:"
echo "   MANUAL_INSTALACION_COMPLETO.md"
echo ""
echo "🚀 Para verificación rápida del sistema:"
echo "   ./check_status.sh"
echo ""
echo "🌐 Para obtener la URL del dashboard:"
echo "   ./setup_dynamic_ip.sh"
echo ""

echo "=== FIN DE VERIFICACIÓN ==="
